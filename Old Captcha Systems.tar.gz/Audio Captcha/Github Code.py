import os
import random
from pydub import AudioSegment
from difflib import SequenceMatcher
import speech_recognition as sr
import subprocess

CONFIG_PATHS = {
    "1": {
        "mp3_folder": os.path.expanduser('/userfiles/Primary Storage Files/Documents/Thesis/Audio Captcha/NoiselessAudio/'),
        "noise_audio_path": os.path.expanduser('/userfiles/Primary Storage Files/Documents/Thesis/Audio Captcha/noise.mp3'),
        "downloads_path": os.path.expanduser('~/Downloads/'),  
        "audio_temp_path": os.path.expanduser('/userfiles/Primary Storage Files/Documents/Thesis/Audio Captcha/AudioTemp/'),
    },
    "2": {
        "mp3_folder": os.path.expanduser('~\\Thesis\\NoiselessAudio'),
        "noise_audio_path": os.path.expanduser('~\\Thesis\\noise.mp3'),
        "downloads_path": os.path.expanduser('~\\Downloads'),
        "audio_temp_path": os.path.expanduser('~\\Thesis\\AudioTemp'),
    },
}

CONFIDENCE_THRESHOLD = 0.5
MAX_RETRY_ATTEMPTS = 3
MAX_FAILED_ATTEMPTS = 3

def clear_terminal():
    os.system('cls' if 'nt' in os.name else 'clear')

def select_random_audio(mp3_folder):
    mp3_files = [file for file in os.listdir(mp3_folder) if file.endswith('.mp3')]
    return random.choice(mp3_files) if mp3_files else None

def recognize_speech(audio_file_path):
    recognizer = sr.Recognizer()
    with sr.AudioFile(audio_file_path) as source:
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.record(source)
        recognition_data = recognizer.recognize_google(audio, show_all=True)['alternative'][0]
        text = recognition_data['transcript']
        confidence = recognition_data.get('confidence', 0)
        return text, confidence

def add_noise(audio, noise):
    return noise + audio + noise

def export_audio(audio, file_path):
    audio.export(file_path, format="wav")

def play_audio(audio_temp_path):
    os.chdir(audio_temp_path)
    subprocess.run(['xdg-open', 'temp_audio.wav'])

def start_file(file_path):
    os.startfile(file_path)

def handle_user_choice(user_choice, config_paths):
    mp3_folder = config_paths.get("mp3_folder")
    noise_audio_path = config_paths.get("noise_audio_path")
    downloads_path = config_paths.get("downloads_path")
    audio_temp_path = config_paths.get("audio_temp_path")

    answer_correct = False
    failed_attempts = 0
    retry_attempts = 0
    download_message = None
    current_audio_file = None

    while not answer_correct:
        clear_terminal()

        if not current_audio_file:
            current_audio_file = select_random_audio(mp3_folder)

        if current_audio_file:
            full_file_path = os.path.join(mp3_folder, current_audio_file)
            audio = AudioSegment.from_mp3(full_file_path)
            noise = AudioSegment.from_mp3(noise_audio_path)
            audio_with_noise = add_noise(audio, noise)

            wav_file_path = os.path.join(audio_temp_path, "temp_audio.wav")
            export_audio(audio_with_noise, wav_file_path)

            text, confidence = recognize_speech(wav_file_path)

            print("Recognized Text:", text)
            print("Recognition Confidence Score:", confidence)

            if download_message:
                print(download_message)

            print("\nMenu:")
            print("1. Play the audio")
            print("2. Download the audio")
            print("3. Retry recognition")
            print("4. Answer the prompt")
            choice = input("Enter your choice (1/2/3/4): ")

            if choice == "1":
                play_audio(audio_temp_path) if user_choice == "1" else start_file('temp_audio.wav')
            elif choice == "2":
                mp3_file_path = os.path.join(downloads_path, "audio.mp3")
                export_audio(audio_with_noise, mp3_file_path)
                download_message = f"Audio downloaded as 'audio.mp3' in Downloads Folder"
            elif choice == "3":
                if retry_attempts < MAX_RETRY_ATTEMPTS:
                    current_audio_file = select_random_audio(mp3_folder)
                    retry_attempts += 1
                else:
                    print("\n You've exceeded the maximum number of retry attempts. You are blocked for a time being.")
                    break
            elif choice == "4":
                user_input = input("\nWhat did you hear in the audio?: ")
                print("\nUser Feedback:", user_input)
                similarity_ratio = SequenceMatcher(None, text, user_input).ratio()
                print("\nText Similarity Ratio:", similarity_ratio)
                result = "Pass" if similarity_ratio >= CONFIDENCE_THRESHOLD else "Fail"
                print(f"\n{result}: Your input {'closely matches' if result == 'Pass' else 'does not closely match'} the recognized text.\n")
                if result == "Pass":
                    answer_correct = True
                elif result == "Fail":
                    answer_correct = False
                    failed_attempts += 1
                    if failed_attempts >= MAX_FAILED_ATTEMPTS:
                        print("\n You've failed to answer correctly 3 times. You are blocked for a time being.")
                        break
            else:
                print("Invalid choice. Please enter a valid option (1/2/3/4).")
        else:
            print("\nNo MP3 files found in the specified folder. Exiting.\n")

def main():
    user_choice = input("\nUser:\n1. Patrick\n2. Elisha\nInput: ")
    config_paths = CONFIG_PATHS.get(user_choice)
    
    if not config_paths:
        print("Invalid user choice.")
        return
    
    handle_user_choice(user_choice, config_paths)

if __name__ == "__main__":
    main()

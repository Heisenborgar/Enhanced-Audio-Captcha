import os
import librosa
import numpy as np
import tkinter as tk
from tkinter import filedialog
import matplotlib.pyplot as plt
import soundfile as sf

def categorize_amplitude(amplitude_db):
    if amplitude_db < 40:
        return "Low"
    elif 40 <= amplitude_db <= 70:
        return "Normal"
    else:
        return "High"

def adjust_amplitude(y, target_db=55):
    rms = np.sqrt(np.mean(y ** 2))
    reference = 1.0
    amplitude_db = 20 * np.log10(rms / reference)
    adjustment_factor = 10 ** ((target_db - amplitude_db) / 20)
    y_adjusted = y * adjustment_factor

    return y_adjusted

def get_audio_info(file_path):
    y, sr = librosa.load(file_path)
    amplitude, audio_signal = calculate_amplitude(y)
    category = categorize_amplitude(amplitude)

    adjusted_audio = adjust_amplitude(y, target_db=10)

    save_option = input("Do you want to save the adjusted audio? (yes/no): ")
    if save_option.lower() == "yes":
        save_file_path = filedialog.asksaveasfilename(title="Save Adjusted Audio", defaultextension=".wav",
                                                          filetypes=[("WAV files", "*.wav")])
        if save_file_path:
            sf.write(save_file_path, adjusted_audio, sr)
            print(f"Adjusted audio saved successfully at: {save_file_path}")

    return audio_signal, adjusted_audio, sr, amplitude, category

def calculate_amplitude(y):
    rms = np.sqrt(np.mean(y ** 2))
    reference = 1.0
    amplitude_db = np.abs(10 * np.log10(rms / reference)) #60 high 10 low
    artificially_adjusted_db = amplitude_db * 2  # Artificial adjustment of dB by a factor of 2
    return artificially_adjusted_db, y

def select_audio_file():
    root = tk.Tk()
    root.withdraw()

    file_path = filedialog.askopenfilename(title="Select Audio File")
    if file_path:
        original_audio, adjusted_audio, sample_rate, orig_amplitude, orig_category = get_audio_info(file_path)

        # # Plotting original audio
        # plt.figure(figsize=(10, 6))
        # plt.subplot(2, 1, 1)
        # times_original = np.linspace(0, len(original_audio) / sample_rate, len(original_audio))
        # plt.plot(times_original, original_audio * (1.0 / np.max(np.abs(original_audio))))
        # plt.title('Original Audio Waveform')
        # plt.xlabel('Time (s)')
        # plt.ylabel('Amplitude')
        # info_text = f"Adjusted Amplitude (in dB): {orig_amplitude:.2f} dB\nCategory: {orig_category}"
        # plt.text(0.05, 0.95, info_text, transform=plt.gca().transAxes,
        #          verticalalignment='top', bbox=dict(facecolor='white', alpha=0.8))
        # plt.ylim(-1.30, 1.30)

        # #Ajusted Amplitude Category must be in normal

        # plt.tight_layout()
        # plt.show()

select_audio_file()

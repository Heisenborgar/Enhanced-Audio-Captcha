import os
import random
from flask import Flask, render_template, request, redirect, url_for, send_file

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    message = ''

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username == "Patrick" and password == "Buyain":
            return redirect(url_for('home'))
        elif username == "Elisha" and password == "Abed":
            return redirect(url_for('home'))
        else:
            message = "No user found."

    return render_template('index.html', message = message, play_audio=True)

@app.route('/get_audio_question')
def get_audio_question():
    audio_folder = 'audio_database/audio_questions'
    audio_files = os.listdir(audio_folder)
    randomly_selected_audio = random.choice(audio_files)
    return send_file(os.path.join(audio_folder, randomly_selected_audio), as_attachment=True)

@app.route('/get_audio_answer/<sound_value>')
def get_audio_answer(sound_value):
    audio_folder = 'audio_database/audio_answers'
    answer_file = f"{sound_value}.m4a"
    answer_path = os.path.join(audio_folder, answer_file)
    
    # Check if the file exists before sending
    if os.path.exists(answer_path):
        return send_file(answer_path, as_attachment=True)
    else:
        return "Audio file not found", 404  # Return a 404 error if the file is not found

@app.route('/home')
def home():
    return render_template('home.html')

if __name__ == "__main__":
    app.run(debug=True)

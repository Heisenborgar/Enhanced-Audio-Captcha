import os
import random
import numpy as np
from flask import Flask, render_template, request, redirect, url_for, send_file
from pydub import AudioSegment

app = Flask(__name__)
app.config['PREFERRED_URL_SCHEME'] = 'https'

@app.after_request
def add_cache_headers(response):
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, proxy-revalidate'
    return response

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        return redirect(url_for('home'))
    return render_template('newsite.html', play_audio=True)

# audio_files = [
#     "audio_database/audio_questions/lion_question.mp3",
#     "audio_database/audio_questions/cat_question.mp3",
# ]

# @app.route('/get_audio_question')
# def get_audio_question():
#     if not audio_files:
#         return "No audio questions available."
#     response = send_file(audio_files[0], mimetype="audio/mp3")
#     response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
#     return response



def check_and_adjust_audio_volume(audio):
   low_threshold = 40
   high_threshold = 70
   volume1 = audio.dBFS;
   rms = np.sqrt(np.mean(volume1 ** 2))
   volume = np.abs(20 * np.log10(rms / 1.0))

   if volume < low_threshold:
    #10
       audio += abs(-5)
       result = f"Low Volume to ({volume} dB))"

   elif low_threshold <= volume <= high_threshold:
       result = "Normal Volume Adjusted"
   else:
       #audio -= abs(volume - -13)
       result = f"High Volume to ({volume} dB))"

   return result, audio

def overlay_noise(audio, noise):
   while len(noise) < len(audio):
       noise = noise + noise

   combined = audio.overlay(noise[:len(audio)], position=0)
   return combined

@app.route('/get_audio_question')
def get_audio_question():
   questions = ['HighVolumeCat']
   randomly_selected_question = random.choice(questions)
   audio_folder = 'audio_database/audio_questions'
   audio_file = "carengine1.wav" 
   audio_path = os.path.join(audio_folder, audio_file)
   audio = AudioSegment.from_file(audio_path, format="wav")
   result, adjusted_audio = check_and_adjust_audio_volume(audio)
   print(result)
   noise_path = 'static/noise.mp3'
   noise = AudioSegment.from_file(noise_path, format="mp3")
   audio_with_noise = overlay_noise(adjusted_audio, noise)
   audio_with_noise_path = 'temp/audio_with_noise.mp3'
   audio_with_noise.export(audio_with_noise_path, format="mp3")
   return send_file(audio_with_noise_path, as_attachment=True)

@app.route('/get_audio_answer/<sound_value>')
def get_audio_answer(sound_value):
   question_to_answer_map = {
       'carengine1': 'carengine2',
       'lion1': 'lion2',
       'cough1': 'cough2'
   }
   
   if sound_value in question_to_answer_map:
       audio_folder = 'audio_database/audio_answers'
       answer_file = f"{question_to_answer_map[sound_value]}.mp3"
       answer_path = os.path.join(audio_folder, answer_file)

       if os.path.exists(answer_path):
           return send_file(answer_path, as_attachment=True)
       else:
           return "Audio file not found", 404
   else:
       return "Invalid sound value", 400
        
audioval = 55.12;

@app.route('/dashboard_page')
def dashboard_page():
    return "You Passed Our Enhanced Audio-CAPTCHA!"

if __name__ == "__main__":
    app.run(port=9999,debug=True)

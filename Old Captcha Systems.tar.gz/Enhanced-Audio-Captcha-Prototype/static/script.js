var countdownInterval;
var countdownTime = 30;
var buttonClickCounter = 0;
var banCount = 3;
var audioBeep;
var audioQuestion;

function updateTimer() {
  var minutes = Math.floor(countdownTime / 60);
  var seconds = countdownTime % 60;
  document.getElementById("timer").innerText =
    minutes + ":" + (seconds < 10 ? "0" : "") + seconds;
}

function startCountdown() {
  clearInterval(countdownInterval);
  countdownInterval = setInterval(function () {
    countdownTime--;
    if (countdownTime <= 0) {
      getNewAudio();
      countdownTime = 30;
    }
    updateTimer();
    if (buttonClickCounter >= banCount) {
      clearInterval(countdownInterval);
    }
  }, 1000);
}

function stopAndResetCountdown() {
  clearInterval(countdownInterval);
  countdownTime = 30;
  updateTimer();
}

function showModal() {
  getNewAudioRequest();
  if (buttonClickCounter >= banCount) {
    alert("You are temporarily banned. Please try again later.");
  } else {
    var captchaModal = document.getElementById("captchaModal");
    captchaModal.style.animation = "fadeIn 0.3s ease-in-out forwards";
    captchaModal.style.display = "flex";
    document.body.style.overflow = "hidden";
    playBeepAndQuestion();
  }
}

function playBeepAndQuestion() {
  audioBeep = new Audio(beepAudioUrl);
  audioQuestion = new Audio(audioQuestionUrl);
  playAudio(audioBeep)
    .then(() => {
      return playAudio(audioQuestion);
    })
    .then(() => {
      startCountdown();
    });
}

function stopBeepAndQuestion() {
  if (audioBeep || audioQuestion) {
    audioBeep.pause();
    audioBeep.currentTime = 0;
    audioQuestion.pause();
    audioQuestion.currentTime = 0;
  }
}

function hideModal(eventType) {
  stopBeepAndQuestion();
  var radioButtons = document.querySelectorAll(
    "#captchaModal input[type='radio']"
  );
  radioButtons.forEach(function (radioButton) {
    radioButton.checked = false;
  });
  if (eventType == 1) {
    var captchaModal = document.getElementById("captchaModal");
    captchaModal.style.animation = "fadeOut 0.3s ease-in-out forwards";
    setTimeout(function () {
      captchaModal.style.display = "none";
    }, 300);
    stopAndResetCountdown();
    document.body.style.overflow = "auto";
    buttonClickCounter++;
    if (buttonClickCounter >= banCount) {
      alert("You are temporarily banned. Please try again later.");
    }
  } else if (eventType == 2) {
    var captchaModal = document.getElementById("captchaModal");
    captchaModal.style.animation = "fadeOut 0.3s ease-in-out forwards";
    setTimeout(function () {
      captchaModal.style.display = "none";
    }, 300);
    stopAndResetCountdown();
    document.body.style.overflow = "auto";
    if (buttonClickCounter >= banCount) {
      alert("You are temporarily banned. Please try again later.");
    }
  }
}

function getNewAudio() {
  buttonClickCounter++;
  if (buttonClickCounter >= banCount) {
    alert("You are temporarily banned. Please try again later.");
  } else {
    getNewAudioRequest();
    getNewAudioAnimation();
  }
}

function getNewAudioRequest() {
  fetch("/get_audio_question") // Make a GET request to your Flask endpoint
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      // Get the filename from the headers
      const filename = response.headers.get("X-Filename");
      console.log("Received audio file:", filename);
      return response.blob();
    })
    .then((blob) => {
      // Process the audio blob as needed (e.g., play it)
    })
    .catch((error) => console.error("Error:", error));
}

function getNewAudioAnimation() {
  var resetButton = document.querySelector(".modal-reset button");
  resetButton.classList.add("clicked");
  setTimeout(function () {
    resetButton.classList.remove("clicked");
  }, 300);
  hideModal(2);
  setTimeout(() => {
    showModal();
  }, 500);
}

function playAudio(audio) {
  return new Promise((resolve) => {
    audio.addEventListener("ended", resolve);
    audio.play();
  });
}

function getCaptchaAnswer(soundValue) {
  let verifyButton = document.getElementById("verifyButton");
  fetch(`/get_audio_answer/${soundValue}`)
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.blob();
    })
    .then((blob) => {
      let audioPlayerElement = document.getElementById("audioPlayerElement");
      let audioUrl = URL.createObjectURL(blob);
      audioPlayerElement.src = audioUrl;
      audioPlayerElement.load();
      audioPlayerElement.play();
      verifyButton.disabled = false;
    })
    .catch((error) => console.error("Error:", error));
  verifyButton.disabled = false;
}

function verifyAnswer() {
  var selectedValue = document.querySelector(
    'input[name="soundOption"]:checked'
  ).value;
  if (selectedValue === "answer") {
    window.location.href = "/dashboard_page"; // Redirect to congrats page
  } else {
    getNewAudio();
  }
}
